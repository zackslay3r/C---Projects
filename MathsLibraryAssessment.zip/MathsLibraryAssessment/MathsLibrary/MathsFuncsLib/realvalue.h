#pragma once

typedef float real;